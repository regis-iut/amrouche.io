/*
  Rui Santos & Sara Santos - Random Nerd Tutorials
  Complete project details at https://RandomNerdTutorials.com/esp-now-esp32-arduino-ide/
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files.
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/
#include <esp_now.h>
#include <WiFi.h>

// REPLACE WITH YOUR RECEIVER MAC Address
uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xAF, 0x74};

// Structure to send data - simplified to just int8_t
typedef struct struct_message {
  int8_t data;
} struct_message;

// Create a struct_message called myData
struct_message myData;

// Your variable to modify - this is what you'll change to send different values
int8_t dataToSend = 1;

esp_now_peer_info_t peerInfo;

// callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}
 
void setup() {
  // Init Serial Monitor
  Serial.begin(115200);
 
  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);
  
  // Register peer
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}
 
void loop() {
  // MODIFIEZ CETTE VARIABLE pour envoyer différentes valeurs
  // Valeurs possibles : -128 à 127
  dataToSend = 2;  // Exemple avec valeur aléatoire
  // dataToSend = 42;              // Ou une valeur fixe
  // dataToSend = analogRead(A0);  // Ou une lecture de capteur
  
  // Copier la valeur dans la structure
  myData.data = dataToSend;
  
  // Send message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
   
  if (result == ESP_OK) {
    Serial.print("Sent with success - Value: ");
    Serial.println(dataToSend);
  }
  else {
    Serial.println("Error sending the data");
  }
  delay(2000);
}