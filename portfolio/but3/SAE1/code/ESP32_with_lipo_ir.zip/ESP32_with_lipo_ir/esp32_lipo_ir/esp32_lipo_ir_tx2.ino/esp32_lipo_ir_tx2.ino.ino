#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>
#include "esp_sleep.h"
#include <Wire.h>
#include <VL53L0X.h>

// ========== RÉGLAGES BATTERIE (XIAO S3) ==========
#define PIN_BATTERIE 1           // GPIO 1 correspond à A0/D1 sur Xiao S3
#define SEUIL_COUPURE 3.3        // Tension min de sécurité
#define FACTEUR_CORRECTION 2.0   // Pont diviseur par 2

// ========== RÉGLAGES I2C (XIAO S3) ==========
#define PIN_SDA 5  // D4 sur Xiao S3
#define PIN_SCL 6  // D5 sur Xiao S3

// ========== RÉGLAGES DE LA BARRIÈRE ==========
#define DISTANCE_DU_MUR 300  
#define MARGE 20 
#define SEUIL_DECLENCHEMENT (DISTANCE_DU_MUR - MARGE)

// 0.2 secondes entre chaque vérification
#define TEMPS_ENTRE_MESURES_US 200000 

uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// ========== VARIABLES ==========
VL53L0X sensor;

typedef struct struct_message {
  int alerte; // 2 = Faisceau coupé
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

// ========== FONCTION : PROTECTION BATTERIE ==========
void verifierBatterie() {
  uint32_t lecture_mV = analogReadMilliVolts(PIN_BATTERIE);
  float tension = (lecture_mV * FACTEUR_CORRECTION) / 1000.0;

  // Si tension critique (et cohérente, >2V), on coupe tout SANS réveil
  if (tension < SEUIL_COUPURE && tension > 2.0) {
    esp_deep_sleep_start();
  }
}

// ========== FONCTION : SOMMEIL CYCLIQUE ==========
void goToSleep() {
  esp_sleep_enable_timer_wakeup(TEMPS_ENTRE_MESURES_US);
  esp_deep_sleep_start();
}

// ========== CALLBACK ESP-NOW (ESP32 V3.X) ==========
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // Une fois l'alerte envoyée, on retourne surveiller
  goToSleep(); 
}

void setup() {
  // 1. Protection Batterie (PRIORITÉ)
  verifierBatterie();

  // 2. Initialisation I2C (Pins S3)
  Wire.begin(PIN_SDA, PIN_SCL);
  
  sensor.setTimeout(500);
  if (!sensor.init()) {
    // Si capteur HS, on dort et on réessaie au prochain cycle
    goToSleep();
  }

  // 3. MESURE INSTANTANÉE
  // On réduit le budget temps du capteur pour aller plus vite (optionnel)
  // sensor.setMeasurementTimingBudget(20000); 

  uint16_t distance = sensor.readRangeSingleMillimeters();
  
  if (sensor.timeoutOccurred()) { 
    distance = 8190; 
  }

  // 4. LOGIQUE DE COUPURE DE FAISCEAU
  // Si distance < Seuil : Quelqu'un est passé
  if (distance < SEUIL_DECLENCHEMENT && distance > 50) { 
    
    // --- FAISCEAU COUPÉ ---
    WiFi.mode(WIFI_STA);
    
    if (esp_now_init() == ESP_OK) { 
        esp_now_register_send_cb(OnDataSent);
        
        memcpy(peerInfo.peer_addr, broadcastAddress, 6);
        peerInfo.channel = 0;  
        peerInfo.encrypt = false;
        
        if (esp_now_add_peer(&peerInfo) == ESP_OK) {
            // Envoi du code "2" pour la seconde balise
            myData.alerte = 2;
            esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
            // Le sleep se fera dans OnDataSent
        } else {
            goToSleep();
        }
    } else {
        goToSleep();
    }

  } else {
    // --- RIEN À SIGNALER ---
    goToSleep();
  }
}

void loop() {}