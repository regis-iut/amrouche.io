#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>
#include "esp_sleep.h"
#include <Wire.h>
#include <VL53L0X.h>

// ========== RÉGLAGES BATTERIE (XIAO S3) ==========
#define PIN_BATTERIE 1           // GPIO 1 correspond à A0/D1 sur Xiao S3
#define SEUIL_COUPURE 3.3        // En dessous de 3.3V, on coupe tout
#define FACTEUR_CORRECTION 2.0   // Car pont diviseur par 2

// ========== RÉGLAGES I2C (XIAO S3) ==========
#define PIN_SDA 5  // D4 sur Xiao S3
#define PIN_SCL 6  // D5 sur Xiao S3

// ========== RÉGLAGES CAPTEUR & LOGIQUE ==========
#define DISTANCE_A_VIDE 300 
#define MARGE 50 
#define SEUIL_PRESENCE (DISTANCE_A_VIDE - MARGE)

#define TEMPS_ENTRE_MESURES_US 200000 

uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// ========== MÉMOIRE PERSISTANTE ==========
RTC_DATA_ATTR bool voiture_etait_la = false; 

// ========== OBJETS ==========
VL53L0X sensor;

typedef struct struct_message {
  int alerte; 
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

// ========== FONCTION : PROTECTION BATTERIE ==========
void verifierBatterie() {
  uint32_t lecture_mV = analogReadMilliVolts(PIN_BATTERIE);
  float tension = (lecture_mV * FACTEUR_CORRECTION) / 1000.0;

  if (tension < SEUIL_COUPURE && tension > 2.0) { 
    esp_deep_sleep_start();
  }
}

// ========== FONCTION : SOMMEIL CYCLIQUE ==========
void goToSleep() {
  esp_sleep_enable_timer_wakeup(TEMPS_ENTRE_MESURES_US);
  esp_deep_sleep_start();
}

// ========== CALLBACK ESP-NOW (CORRIGÉ POUR ESP32 V3.X) ==========
// C'est ici que l'erreur se produisait. 
// On remplace 'const uint8_t *mac_addr' par 'const wifi_tx_info_t *info'
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // Une fois le message envoyé (réussi ou échec), on retourne dormir
  goToSleep(); 
}

void setup() {
  // 1. Protection Batterie
  verifierBatterie();

  // 2. Init I2C 
  Wire.begin(PIN_SDA, PIN_SCL);

  // 3. Init Capteur
  sensor.setTimeout(500);
  if (!sensor.init()) { 
    goToSleep(); 
  }

  // 4. Mesure
  uint16_t distance = sensor.readRangeSingleMillimeters();
  if (sensor.timeoutOccurred()) { distance = 8190; }

  // 5. ANALYSE
  bool voiture_est_la_maintenant = (distance < SEUIL_PRESENCE && distance > 20);

  // 6. LOGIQUE
  if (voiture_etait_la == true && voiture_est_la_maintenant == false) {
    
    voiture_etait_la = false; 

    WiFi.mode(WIFI_STA);
    
    if (esp_now_init() == ESP_OK) {
      esp_now_register_send_cb(OnDataSent);
      
      memcpy(peerInfo.peer_addr, broadcastAddress, 6);
      peerInfo.channel = 0;  
      peerInfo.encrypt = false;
      
      if (esp_now_add_peer(&peerInfo) != ESP_OK) {
        goToSleep(); 
      }

      myData.alerte = 1; 
      esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
      // Le sleep se fait dans OnDataSent
    } else {
      goToSleep(); 
    }

  } 
  else if (voiture_etait_la == false && voiture_est_la_maintenant == true) {
    voiture_etait_la = true; 
    goToSleep();
  }
  else {
    goToSleep();
  }
}

void loop() {}