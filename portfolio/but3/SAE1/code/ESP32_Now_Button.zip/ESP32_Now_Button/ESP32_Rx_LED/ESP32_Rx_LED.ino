/*
  Rui Santos & Sara Santos - Random Nerd Tutorials
  Adapté : si data == 1 -> D22 HIGH, si data == 2 -> D23 HIGH
*/

#include <esp_now.h>
#include <WiFi.h>

// Structure to receive data - must match sender structure
typedef struct struct_message {
  int8_t data;
} struct_message;

// Create a struct_message called myData
struct_message myData;

// Définir les pins de sortie
#define PIN_OUT1 2
#define PIN_OUT2 23

// Nouveau prototype du callback (ESP-IDF v5.x)
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  memcpy(&myData, incomingData, sizeof(myData));
  Serial.print("Data received: ");
  Serial.println(myData.data);

  if (myData.data == 1) {
    digitalWrite(PIN_OUT1, HIGH);
    delay(250);
    digitalWrite(PIN_OUT1, LOW);
    Serial.println("Pin 2 HIGH");
  } 
  else if (myData.data == 2) {
    digitalWrite(PIN_OUT2, HIGH);
    delay(250);
    digitalWrite(PIN_OUT2, LOW);
    Serial.println("Pin 23 HIGH");
  }
}
 
void setup() {
  // Initialize Serial Monitor
  Serial.begin(115200);

  // Configurer les pins en sortie
  pinMode(PIN_OUT1, OUTPUT);
  pinMode(PIN_OUT2, OUTPUT);

  // Mettre à LOW au départ
  digitalWrite(PIN_OUT1, LOW);
  digitalWrite(PIN_OUT2, LOW);
  
  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  
  // Register for recv callback
  esp_now_register_recv_cb(OnDataRecv);
}
 
void loop() {
  // Rien à faire en continu, tout est géré par le callback
}
