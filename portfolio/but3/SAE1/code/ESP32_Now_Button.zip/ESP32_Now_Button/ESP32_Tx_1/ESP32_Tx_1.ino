/*
  ESP32 Deep Sleep avec ESP-NOW
  Adapté pour se réveiller avec un bouton et transmettre des données
  Basé sur Rui Santos & Sara Santos - Random Nerd Tutorials
*/
#include <esp_now.h>
#include <WiFi.h>
#include "esp_sleep.h"

// REMPLACEZ PAR L'ADRESSE MAC DE VOTRE RÉCEPTEUR
uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// Structure pour envoyer les données
typedef struct struct_message {
  int8_t data;
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

// Pin du bouton (GPIO25)
#define BUTTON_PIN 25
// Temps de veille en microsecondes (exemple: 30 secondes)
#define uS_TO_S_FACTOR 1000000ULL
#define TIME_TO_SLEEP 30

// Variable pour compter les réveils
RTC_DATA_ATTR int bootCount = 0;

// Callback d'envoi des données
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  Serial.print("Status d'envoi du dernier paquet: ");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Succès" : "Échec");
  
  // Attendre un peu puis retourner en veille
  delay(500); // Délai plus long pour voir les messages
  Serial.println("Message envoyé, retour en veille...");
  Serial.flush();
  goToSleep();
}

// Fonction pour analyser la cause du réveil
void print_wakeup_reason(){
  esp_sleep_wakeup_cause_t wakeup_reason;
  wakeup_reason = esp_sleep_get_wakeup_cause();

  switch(wakeup_reason) {
    case ESP_SLEEP_WAKEUP_EXT0 : 
      Serial.println("Réveil causé par un signal externe (RTC_IO)"); 
      break;
    case ESP_SLEEP_WAKEUP_EXT1 : 
      Serial.println("Réveil causé par un signal externe (RTC_CNTL)"); 
      break;
    case ESP_SLEEP_WAKEUP_TIMER : 
      Serial.println("Réveil causé par le timer"); 
      break;
    case ESP_SLEEP_WAKEUP_TOUCHPAD : 
      Serial.println("Réveil causé par le touchpad"); 
      break;
    case ESP_SLEEP_WAKEUP_ULP : 
      Serial.println("Réveil causé par le programme ULP"); 
      break;
    default : 
      Serial.printf("Réveil non causé par le deep sleep: %d\n", wakeup_reason);
      break;
  }
}

// Fonction pour entrer en mode veille
void goToSleep() {
  Serial.println("Configuration du réveil par bouton...");
  
  // Configuration du réveil par signal externe sur GPIO23 avec EXT1
  // GPIO23 n'est pas compatible avec EXT0, on utilise EXT1
  // Masque de bits pour GPIO23
  uint64_t ext_wakeup_pin_1_mask = 1ULL << BUTTON_PIN;
  
  // Configuration EXT1 pour réveil sur HIGH (bouton à 3.3V)
  esp_sleep_enable_ext1_wakeup(ext_wakeup_pin_1_mask, ESP_EXT1_WAKEUP_ANY_HIGH);
  
  // Optionnel : réveil par timer après X secondes d'inactivité
  esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR);
  
  Serial.println("Entrée en mode Deep Sleep...");
  Serial.flush();
  
  // Entrer en deep sleep
  esp_deep_sleep_start();
}

void setup() {
  Serial.begin(115200);
  delay(50);

  // Incrémenter le compteur de boot et l'afficher
  ++bootCount;
  Serial.println("Nombre de réveils: " + String(bootCount));

  // Afficher la raison du réveil
  print_wakeup_reason();

  // Configuration du bouton en entrée (sans pull-up car signal externe 3.3V)
  pinMode(BUTTON_PIN, INPUT_PULLDOWN);

  // Vérifier si on s'est réveillé à cause du bouton
  esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();
  
  if (wakeup_reason != ESP_SLEEP_WAKEUP_TIMER || bootCount == 1) {
    // On s'est réveillé à cause du bouton ou c'est le premier démarrage
    Serial.println("Réveil par bouton détecté - Initialisation ESP-NOW...");
    
    // Configuration Wi-Fi
    WiFi.mode(WIFI_STA);

    // Initialisation ESP-NOW
    if (esp_now_init() != ESP_OK) {
      Serial.println("Erreur initialisation ESP-NOW");
      goToSleep();
      return;
    }

    // Enregistrement du callback d'envoi
    esp_now_register_send_cb(OnDataSent);

    // Enregistrement du peer
    memcpy(peerInfo.peer_addr, broadcastAddress, 6);
    peerInfo.channel = 0;
    peerInfo.encrypt = false;

    if (esp_now_add_peer(&peerInfo) != ESP_OK){
      Serial.println("Échec ajout du peer");
      goToSleep();
      return;
    }

    // Préparer et envoyer les données
    myData.data = 1;
    
    Serial.println("Envoi des données...");
    esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));

    if (result == ESP_OK) {
      Serial.println("Bouton pressé -> Valeur envoyée: 2");
      // Le callback OnDataSent gérera le retour en veille
      // On attend ici que l'envoi soit terminé
      delay(100); // Petit délai pour laisser le temps à l'envoi
    } else {
      Serial.println("Erreur envoi des données");
      delay(1000);
      goToSleep();
    }
  } else {
    // Réveil par timer ou autre - retourner directement en veille
    Serial.println("Réveil par timer - Retour en veille");
    goToSleep();
  }
}

void loop() {
  // On ne devrait jamais arriver ici avec le deep sleep
  // mais au cas où, on attend un peu puis on retourne en veille
  Serial.println("Dans le loop - retour en veille");
  delay(250);
  goToSleep();
}