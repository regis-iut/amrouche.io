/*
  Rui Santos & Sara Santos - Random Nerd Tutorials
  Adapté : envoi uniquement quand le bouton D23 est pressé
*/
#include <esp_now.h>
#include <WiFi.h>

// REPLACE WITH YOUR RECEIVER MAC Address
uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// Structure to send data - simplified to just int8_t
typedef struct struct_message {
  int8_t data;
} struct_message;

// Create a struct_message called myData
struct_message myData;

esp_now_peer_info_t peerInfo;

// Pin du bouton
#define BUTTON_PIN 23

// Nouveau prototype du callback (ESP-IDF v5.x)
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

void setup() {
  // Init Serial Monitor
  Serial.begin(115200);

  // Configurer le bouton en entrée
  pinMode(BUTTON_PIN, INPUT);

  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Register for Send Callback
  esp_now_register_send_cb(OnDataSent);

  // Register peer
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}

void loop() {
  // Lire l’état du bouton (LOW = appuyé car pull-up activée)
  if (digitalRead(BUTTON_PIN) == HIGH) {
    myData.data = 2;

    // Envoi du message
    esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));

    if (result == ESP_OK) {
      Serial.println("Button pressed -> Sent value: 1");
    } else {
      Serial.println("Error sending the data");
    }

    delay(300); // petit délai anti-rebond
  }
}
