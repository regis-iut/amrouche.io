#include <esp_now.h>
#include <WiFi.h>
#include "esp_sleep.h"
#include <Wire.h>
#include <VL53L0X.h>

// ========== RÉGLAGES DE LA BARRIÈRE ==========

// Distance de votre mur/réflecteur en face (en mm)
// Mesurez la distance exacte entre le capteur et le mur opposé
#define DISTANCE_DU_MUR 300  

// Marge de tolérance (en mm)
// On alerte si la mesure est inférieure au Mur - cette Marge
#define MARGE 20 

// Calcul automatique du seuil de déclenchement
// Exemple: 1500 - 200 = 1300mm. Tout ce qui est en dessous déclenche l'alerte.
#define SEUIL_DECLENCHEMENT (DISTANCE_DU_MUR - MARGE)

// IMPORTANT : Fréquence de vérification
// Si vous dormez trop longtemps, la personne aura le temps de passer sans être vue !
// 0.2 secondes (200ms) est un bon compromis pour capter quelqu'un qui marche.
#define TEMPS_ENTRE_MESURES_US 200000 

// Adresse du récepteur
uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// ========== VARIABLES ==========

VL53L0X sensor;

typedef struct struct_message {
  int alerte; // 1 = Faisceau coupé
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

// ========== FONCTIONS ==========

void goToSleep() {
  // On utilise le timer pour se réveiller très vite
  esp_sleep_enable_timer_wakeup(TEMPS_ENTRE_MESURES_US);
  esp_deep_sleep_start();
}

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // Une fois l'alerte envoyée, on retourne surveiller
  goToSleep(); 
}

void setup() {
  // On n'active pas le Serial pour aller plus vite et économiser la batterie
  // Serial.begin(115200); 

  // 1. Initialisation I2C et Capteur
  Wire.begin();
  sensor.setTimeout(500);
  
  if (!sensor.init()) {
    // Si le capteur ne répond pas, on dort et on réessaie plus tard
    goToSleep();
  }

  // 2. MESURE INSTANTANÉE
  // On fait une mesure unique
  uint16_t distance = sensor.readRangeSingleMillimeters();
  
  // Si timeout, cela veut dire "rien devant" ou "trop loin" (donc le mur est loin)
  // On considère que la voie est libre si timeout.
  if (sensor.timeoutOccurred()) { 
    distance = 8190; // Valeur max du capteur
  }

  // 3. LOGIQUE DE COUPURE DE FAISCEAU
  // Si la distance mesurée est PLUS PETITE que le seuil, c'est qu'il y a un obstacle
  
  if (distance < SEUIL_DECLENCHEMENT && distance > 50) { // > 50 pour éviter le bruit
    
    // --- FAISCEAU COUPÉ (OBSTACLE DÉTECTÉ) ---
    
    // On allume le WiFi seulement maintenant
    WiFi.mode(WIFI_STA);
    if (esp_now_init() != ESP_OK) { goToSleep(); }
    
    // Config Peer
    esp_now_register_send_cb(OnDataSent);
    memcpy(peerInfo.peer_addr, broadcastAddress, 6);
    peerInfo.channel = 0;  
    peerInfo.encrypt = false;
    esp_now_add_peer(&peerInfo);

    // Envoi du "1"
    myData.alerte = 2;
    esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
    
    // Le deep sleep sera déclenché par la fonction OnDataSent après l'envoi

  } else {
    
    // --- FAISCEAU INTACT (RIEN À SIGNALER) ---
    // On retourne dormir immédiatement
    goToSleep();
  }
}

void loop() {
}