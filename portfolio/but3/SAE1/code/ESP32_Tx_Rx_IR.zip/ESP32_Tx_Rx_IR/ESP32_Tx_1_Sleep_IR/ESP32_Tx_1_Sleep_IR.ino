#include <esp_now.h>
#include <WiFi.h>
#include "esp_sleep.h"
#include <Wire.h>
#include <VL53L0X.h>

// ========== RÉGLAGES ==========

// Distance mesurée quand le garage est VIDE (le sol ou le mur du fond)
#define DISTANCE_A_VIDE 300  

// Marge de sécurité
#define MARGE 50 

// Si la distance est INFERIEURE à (300 - 50 = 250mm), on considère que la voiture est là.
// Si la distance est SUPERIEURE, on considère que c'est vide.
#define SEUIL_PRESENCE (DISTANCE_A_VIDE - MARGE)

#define TEMPS_ENTRE_MESURES_US 200000 
uint8_t broadcastAddress[] = {0x88, 0x13, 0xBF, 0x71, 0xD1, 0x20};

// ========== MÉMOIRE PERSISTANTE ==========

// Cette variable survit au Deep Sleep !
// Elle permet de savoir si la voiture était là lors de la dernière mesure.
RTC_DATA_ATTR bool voiture_etait_la = false; 

// ========== VARIABLES ==========

VL53L0X sensor;

typedef struct struct_message {
  int alerte; // 1 = Départ détecté
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

// ========== FONCTIONS ==========

void goToSleep() {
  esp_sleep_enable_timer_wakeup(TEMPS_ENTRE_MESURES_US);
  esp_deep_sleep_start();
}

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  goToSleep(); 
}

void setup() {
  // 1. Init Capteur
  Wire.begin();
  sensor.setTimeout(500);
  if (!sensor.init()) { goToSleep(); }

  // 2. Mesure
  uint16_t distance = sensor.readRangeSingleMillimeters();
  if (sensor.timeoutOccurred()) { distance = 8190; }

  // 3. ANALYSE DE LA SITUATION ACTUELLE
  
  // Est-ce que la voiture est présente MAINTENANT ?
  // Elle est là si la distance est COURTE (l'objet bloque la vue du sol/mur)
  bool voiture_est_la_maintenant = (distance < SEUIL_PRESENCE && distance > 20);

  // 4. LOGIQUE DE COMPARAISON (C'est ici que la magie opère)

  // CAS 1 : DÉPART DÉTECTÉ
  // La voiture était là avant (True) ET n'est plus là maintenant (False)
  if (voiture_etait_la == true && voiture_est_la_maintenant == false) {
    
    // On met à jour la mémoire pour ne pas renvoyer l'alerte la prochaine fois
    voiture_etait_la = false; 

    // On prépare l'envoi WiFi
    WiFi.mode(WIFI_STA);
    if (esp_now_init() == ESP_OK) {
      esp_now_register_send_cb(OnDataSent);
      memcpy(peerInfo.peer_addr, broadcastAddress, 6);
      peerInfo.channel = 0;  
      peerInfo.encrypt = false;
      esp_now_add_peer(&peerInfo);

      myData.alerte = 1; // Code 1 pour "Départ"
      esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
      // Le sleep se fera dans OnDataSent
    } else {
      goToSleep();
    }

  } 
  // CAS 2 : ARRIVÉE DÉTECTÉE (Optionnel)
  // La voiture n'était pas là, et elle vient d'arriver.
  // On met juste à jour la mémoire silencieusement, sans alerte WiFi.
  else if (voiture_etait_la == false && voiture_est_la_maintenant == true) {
    voiture_etait_la = true; 
    goToSleep();
  }
  // CAS 3 : RIEN NE CHANGE
  // La voiture est toujours là OU le garage est toujours vide.
  else {
    // On ne fait rien, on retourne dormir
    goToSleep();
  }
}

void loop() {}