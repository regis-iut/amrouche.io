#include <WiFi.h>
#include <esp_now.h>
#include <Wire.h>
#include <SPI.h>
#include <LittleFS.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_PN532.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <vector>
#include <algorithm>

/////////////////////////////////      CONFIGURATIONS DES PINS   /////////////////////////////////

//  RFID (SPI)
#define PN532_SCK  18
#define PN532_MISO 19
#define PN532_MOSI 23
#define PN532_SS   5
Adafruit_PN532 nfc(PN532_SCK, PN532_MISO, PN532_MOSI, PN532_SS);

// ECRAN OLED (I2C) 
#define LARGEUR_ECRAN 128
#define HAUTEUR_ECRAN 64
#define ADRESSE_ECRAN 0x3C // Adresse par défaut pour les écrans SSD1306
Adafruit_SSD1306 ecranOled(LARGEUR_ECRAN, HAUTEUR_ECRAN, &Wire, -1);

// WIFI & WEB
const char* ssid = "ESP32_Chrono_System";
const char* password = NULL;
AsyncWebServer server(80);

// HARDWARE DIVERS 
#define PIN_LED_VERTE 2
#define PIN_LED_ROUGE 4

///////////////////////////////// VARIABLES GLOBALES /////////////////////////////////

enum EtatDuJeu {
  ETAT_ATTENTE_BADGE, // 0
  ETAT_PRET_A_PARTIR, // 1
  ETAT_EN_COURSE,     // 2
  ETAT_FINI,          // 3
  ETAT_INSCRIPTION    // 4
};

EtatDuJeu etatActuel = ETAT_ATTENTE_BADGE;
String uidActuel = "";       
String nomJoueurActuel = "";
String uidEnAttente = "";       

unsigned long debutChrono = 0;
unsigned long tempsFinal = 0;
unsigned long derniereMaJAffichage = 0;

typedef struct message_recu {
  int8_t donnee; // 1 = start, 2 = stop
} message_recu;
message_recu monMessage;

struct ScoreJoueur {
  String name;
  unsigned long time;
};

// Helper: Formater temps en 00:00.00
String formatTemps(unsigned long ms) {
  unsigned long mins = (ms / 1000) / 60;
  unsigned long secs = (ms / 1000) % 60;
  unsigned long cents = (ms % 1000) / 10;
  char buf[20];
  sprintf(buf, "%02lu:%02lu.%02lu", mins, secs, cents);
  return String(buf);
}

///////////////////////////////// GESTION FICHIER CSV & CLASSEMENT /////////////////////////////////

String obtenirNomJoueur(String uid) {
  File file = LittleFS.open("/data.csv", "r");
  if (!file) return "";

  while (file.available()) {
    String line = file.readStringUntil('\n');
    line.trim();
    int firstSemi = line.indexOf(';');
    if (firstSemi > 0) {
      String lineUID = line.substring(0, firstSemi);
      if (lineUID.equalsIgnoreCase(uid)) {
        int secondSemi = line.indexOf(';', firstSemi + 1);
        String name = line.substring(firstSemi + 1, secondSemi);
        file.close();
        return name;
      }
    }
  }
  file.close();
  return "";
}

void ajouterNouveauJoueur(String uid, String name) {
  File file = LittleFS.open("/data.csv", "a");
  if (file) {
    file.printf("%s;%s;0\n", uid.c_str(), name.c_str());
    file.close();
  }
}

void mettreAJourMeilleurTemps(String uid, unsigned long newTime) {
  File fileRead = LittleFS.open("/data.csv", "r");
  File fileWrite = LittleFS.open("/temp.csv", "w");
  if (!fileRead || !fileWrite) return;

  while (fileRead.available()) {
    String line = fileRead.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;

    int firstSemi = line.indexOf(';');
    int secondSemi = line.indexOf(';', firstSemi + 1);
    
    if (firstSemi > 0 && secondSemi > 0) {
      String f_uid = line.substring(0, firstSemi);
      String f_name = line.substring(firstSemi + 1, secondSemi);
      String f_timeStr = line.substring(secondSemi + 1);
      unsigned long f_bestTime = f_timeStr.toInt();

      if (f_uid.equalsIgnoreCase(uid)) {
        if (f_bestTime == 0 || newTime < f_bestTime) {
          fileWrite.printf("%s;%s;%lu\n", f_uid.c_str(), f_name.c_str(), newTime);
        } else {
          fileWrite.println(line);
        }
      } else {
        fileWrite.println(line);
      }
    }
  }
  fileRead.close();
  fileWrite.close();
  LittleFS.remove("/data.csv");
  LittleFS.rename("/temp.csv", "/data.csv");
}

String obtenirLeJSONClassement() {
  std::vector<ScoreJoueur> scores;
  
  File file = LittleFS.open("/data.csv", "r");
  if (file) {
    while (file.available()) {
      String line = file.readStringUntil('\n');
      line.trim();
      int firstSemi = line.indexOf(';');
      int secondSemi = line.indexOf(';', firstSemi + 1);
      
      if (firstSemi > 0 && secondSemi > 0) {
        String name = line.substring(firstSemi + 1, secondSemi);
        String timeStr = line.substring(secondSemi + 1);
        unsigned long timeVal = timeStr.toInt();
        if (timeVal > 0) scores.push_back({name, timeVal});
      }
    }
    file.close();
  }

  std::sort(scores.begin(), scores.end(), [](const ScoreJoueur& a, const ScoreJoueur& b) {
    return a.time < b.time;
  });

  String json = "[";
  for (size_t i = 0; i < scores.size(); i++) {
    if (i > 0) json += ",";
    json += "{";
    json += "\"rank\":" + String(i + 1) + ",";
    json += "\"name\":\"" + scores[i].name + "\",";
    json += "\"time\":\"" + formatTemps(scores[i].time) + "\"";
    json += "}";
    if (i >= 19) break; 
  }
  json += "]";
  return json;
}

///////////////////////////////// AFFICHAGE OLED /////////////////////////////////

void mettreAJourAffichage() {
  ecranOled.clearDisplay();
  ecranOled.setTextColor(SSD1306_WHITE);

  if (etatActuel == ETAT_ATTENTE_BADGE) {
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 0); ecranOled.print("SYSTEME PRET");
    ecranOled.setTextSize(2); ecranOled.setCursor(10, 25); ecranOled.print("SCANNEZ");
    ecranOled.setCursor(20, 45); ecranOled.print("BADGE");
  } else if (etatActuel == ETAT_PRET_A_PARTIR) {
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 0); ecranOled.print("JOUEUR:");
    ecranOled.setCursor(0, 12); ecranOled.print(nomJoueurActuel);
    ecranOled.setTextSize(2); ecranOled.setCursor(0, 35); ecranOled.print("PRET ->");
  } else if (etatActuel == ETAT_EN_COURSE) {
    unsigned long current = millis() - debutChrono;
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 0); ecranOled.print("EN COURSE: "); ecranOled.print(nomJoueurActuel);
    ecranOled.setTextSize(2); ecranOled.setCursor(5, 30); ecranOled.print(formatTemps(current));
  } else if (etatActuel == ETAT_FINI) {
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 0); ecranOled.print("FINI: "); ecranOled.print(nomJoueurActuel);
    ecranOled.setTextSize(2); ecranOled.setCursor(5, 25); ecranOled.print(formatTemps(tempsFinal));
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 50); ecranOled.print("Enregistre !");
  } else if (etatActuel == ETAT_INSCRIPTION) {
    ecranOled.setTextSize(1); ecranOled.setCursor(0, 0); ecranOled.print("INCONNU");
    ecranOled.setCursor(0, 20); ecranOled.print("INSCRIPTION WEB");
    ecranOled.setCursor(0, 40); ecranOled.print("192.168.4.1");
  }
  ecranOled.display();
}

///////////////////////////////// ESP-NOW & SETUP /////////////////////////////////

void receptionDonneesEspNow(const esp_now_recv_info *infos, const uint8_t *incomingData, int len) {
  memcpy(&monMessage, incomingData, sizeof(monMessage));
  if (monMessage.donnee == 1) { 
    debutChrono = millis();
    etatActuel = ETAT_EN_COURSE;
    digitalWrite(PIN_LED_VERTE, HIGH);
  } else if (monMessage.donnee == 2) { 
    if (etatActuel == ETAT_EN_COURSE) {
      tempsFinal = millis() - debutChrono;
      etatActuel = ETAT_FINI;
      digitalWrite(PIN_LED_VERTE, LOW);
      digitalWrite(PIN_LED_ROUGE, HIGH);
      if (nomJoueurActuel != "" && uidActuel != "") mettreAJourMeilleurTemps(uidActuel, tempsFinal);
      delay(2000); 
      digitalWrite(PIN_LED_ROUGE, LOW);
    }
  }
}

void initialiserServeurWeb() {
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    String html = R"rawliteral(
<!DOCTYPE html>
<html lang='fr'>
<head>
  <meta charset='UTF-8'>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chrono RFID</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; background: #f0f2f5; margin: 0; padding: 10px; }
    .container { max-width: 600px; margin: auto; }
    .card { background: white; padding: 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    h1 { color: #1a1a1a; margin-bottom: 5px; }
    h2 { color: #444; border-bottom: 2px solid #eee; padding-bottom: 10px; }
    .chrono-box { font-size: 3.5em; font-family: monospace; font-weight: bold; color: #2c3e50; background: #ecf0f1; padding: 15px; border-radius: 8px; margin: 20px 0; }
    .status-text { font-size: 1.2em; font-weight: bold; color: #7f8c8d; }
    .hidden { display: none; }
    
    input[type=text] { width: 80%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 16px; margin: 10px 0; }
    
    .btn { border: none; padding: 12px 24px; border-radius: 6px; font-size: 16px; cursor: pointer; transition: background 0.3s; color: white; display: inline-block; margin: 5px;}
    .btn-green { background: #27ae60; }
    .btn-green:hover { background: #219150; }
    .btn-blue { background: #3498db; padding: 8px 16px; font-size: 14px; }
    
    /* Bouton déconnexion en rouge/orange */
    .btn-logout { background: #e67e22; }
    .btn-logout:hover { background: #d35400; }

    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    th { background-color: #f8f9fa; color: #666; font-weight: 600; }
    tr:nth-child(1) td { color: #d35400; font-weight: bold; } 
    tr:nth-child(2) td { color: #7f8c8d; font-weight: bold; } 
    tr:nth-child(3) td { color: #d35400; filter: sepia(1); font-weight: bold; } 

    .admin-link { color: #95a5a6; font-size: 0.9em; text-decoration: none; margin: 0 10px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <h1>Chrono ESP32</h1>
      
      <div id="main-view">
        <div class="status-text" id="lbl-status">En attente...</div>
        <div class="chrono-box" id="lbl-chrono">00:00.00</div>
        <div id="lbl-player" style="color: #2980b9; font-weight: bold; font-size: 1.2em;">--</div>
        
        <br>
        <button id="btn-logout" class="btn btn-logout hidden" onclick="logoutPlayer()">✖ Déconnexion / Joueur Suivant</button>
      </div>

      <div id="reg-view" class="hidden">
        <h2 style="color: #e74c3c;">Nouveau Joueur Détecté</h2>
        <p>UID Badge : <strong id="lbl-uid"></strong></p>
        <p>Entrez votre nom pour rejoindre la course :</p>
        <input type="text" id="inp-nom" placeholder="Votre Prénom" autocomplete="off">
        <br>
        <button class="btn btn-green" onclick="savePlayer()">Enregistrer & Jouer</button>
        <br><br>
        <button class="btn btn-logout" onclick="logoutPlayer()">Annuler</button>
      </div>
    </div>

    <div class="card">
      <h2>Classement Général</h2>
      <table id="leaderboard">
        <thead>
          <tr>
            <th width="15%">#</th>
            <th>Pilote</th>
            <th width="30%">Temps</th>
          </tr>
        </thead>
        <tbody id="leaderboard-body">
          <tr><td colspan="3" style="text-align:center;">Chargement...</td></tr>
        </tbody>
      </table>
      <br>
      <button class="btn btn-blue" onclick="loadLeaderboard()">Actualiser</button>
    </div>

    <div style="margin-top: 20px;">
       <a href="/data.csv" class="admin-link">Télécharger CSV</a>
       <a href="/reset" class="admin-link" onclick="return confirm('Attention: Cela va effacer tous les temps et joueurs !');">Reset BDD</a>
    </div>
  </div>

<script>
  function fmt(ms) {
    let min = Math.floor(ms / 60000);
    let sec = Math.floor((ms % 60000) / 1000);
    let cen = Math.floor((ms % 1000) / 10);
    return (min<10?"0":"")+min + ":" + (sec<10?"0":"")+sec + "." + (cen<10?"0":"")+cen;
  }

  // MISE A JOUR STATUS
  setInterval(() => {
    fetch('/status').then(r => r.json()).then(d => {
      // Gestion Inscription
      if (d.etat == 4) { 
        document.getElementById('main-view').classList.add('hidden');
        document.getElementById('reg-view').classList.remove('hidden');
        document.getElementById('lbl-uid').innerText = d.pending_uid;
      } else {
        document.getElementById('main-view').classList.remove('hidden');
        document.getElementById('reg-view').classList.add('hidden');
      }

      // Gestion Bouton Déconnexion (Visible si etat != 0 (Attente))
      if (d.etat != 0 && d.etat != 4) {
        document.getElementById('btn-logout').classList.remove('hidden');
      } else {
        document.getElementById('btn-logout').classList.add('hidden');
      }

      document.getElementById('lbl-player').innerText = d.joueur ? "Pilote : " + d.joueur : "En attente de badge...";
      
      let chronoDiv = document.getElementById('lbl-chrono');
      let statusDiv = document.getElementById('lbl-status');

      if(d.etat == 2) { 
        statusDiv.innerText = "COURS !";
        statusDiv.style.color = "#27ae60";
        chronoDiv.innerText = fmt(d.temps_courant);
        chronoDiv.style.color = "#e74c3c";
      } else if (d.etat == 3) { 
        statusDiv.innerText = "TEMPS FINAL";
        statusDiv.style.color = "#2980b9";
        chronoDiv.innerText = fmt(d.temps_final);
        chronoDiv.style.color = "#2c3e50";
        if(!window.refreshLock) { loadLeaderboard(); window.refreshLock = true; setTimeout(()=>window.refreshLock=false, 5000); }
      } else {
        statusDiv.innerText = "PRÊT";
        statusDiv.style.color = "#7f8c8d";
        chronoDiv.style.color = "#bdc3c7";
      }
    });
  }, 200);

  function loadLeaderboard() {
    fetch('/leaderboard').then(r => r.json()).then(data => {
      let tbody = document.getElementById('leaderboard-body');
      tbody.innerHTML = "";
      if(data.length === 0) {
        tbody.innerHTML = "<tr><td colspan='3' style='text-align:center;'>Aucun temps enregistré</td></tr>";
        return;
      }
      data.forEach(row => {
        let tr = `<tr><td>${row.rank}</td><td>${row.name}</td><td>${row.time}</td></tr>`;
        tbody.innerHTML += tr;
      });
    });
  }

  function savePlayer() {
    let nom = document.getElementById('inp-nom').value;
    if(!nom) return alert("Merci d'entrer un nom !");
    fetch('/register?nom=' + encodeURIComponent(nom), {method: 'POST'}).then(() => {
      window.location.reload();
    });
  }

  // NOUVELLE FONCTION DE DÉCONNEXION
  function logoutPlayer() {
    fetch('/logout').then(() => {
        // Pas besoin de reload, le setInterval mettra à jour l'état tout seul
        console.log("Joueur déconnecté");
    });
  }

  loadLeaderboard();
</script>
</body>
</html>
    )rawliteral";
    request->send(200, "text/html; charset=utf-8", html);
  });

  server.on("/status", HTTP_GET, [](AsyncWebServerRequest *request){
    String json = "{";
    json += "\"etat\":" + String(etatActuel) + ",";
    json += "\"joueur\":\"" + nomJoueurActuel + "\",";
    json += "\"pending_uid\":\"" + uidEnAttente + "\",";
    unsigned long t = (etatActuel == ETAT_EN_COURSE) ? (millis() - debutChrono) : tempsFinal;
    json += "\"temps_courant\":" + String(t) + ",";
    json += "\"temps_final\":" + String(tempsFinal);
    json += "}";
    request->send(200, "application/json", json);
  });

  server.on("/leaderboard", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "application/json", obtenirLeJSONClassement());
  });

  server.on("/register", HTTP_POST, [](AsyncWebServerRequest *request){
    if (request->hasParam("nom")) {
      String name = request->getParam("nom")->value();
      ajouterNouveauJoueur(uidEnAttente, name);
      uidActuel = uidEnAttente;
      nomJoueurActuel = name;
      etatActuel = ETAT_PRET_A_PARTIR;
      uidEnAttente = "";
      request->send(200, "text/plain", "OK");
    } else request->send(400, "text/plain", "Erreur");
  });

  // --- NOUVELLE ROUTE LOGOUT ---
  server.on("/logout", HTTP_GET, [](AsyncWebServerRequest *request){
    // Réinitialisation forcée
    etatActuel = ETAT_ATTENTE_BADGE;
    uidActuel = "";
    nomJoueurActuel = "";
    uidEnAttente = "";
    request->send(200, "text/plain", "Logged Out");
  });

  server.on("/data.csv", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(LittleFS, "/data.csv", "text/csv");
  });
  server.on("/reset", HTTP_GET, [](AsyncWebServerRequest *request){
    LittleFS.remove("/data.csv");
    nomJoueurActuel = ""; uidActuel = ""; uidEnAttente = "";
    request->send(200, "text/html; charset=utf-8", "Base effacée. <a href='/'>Retour</a>");
  });

  server.begin();
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_LED_VERTE, OUTPUT);
  pinMode(PIN_LED_ROUGE, OUTPUT);

  if(!LittleFS.begin(true)) return;
  
  Wire.begin(21, 22);
  if(!ecranOled.begin(SSD1306_SWITCHCAPVCC, ADRESSE_ECRAN)) while(1);
  ecranOled.display(); delay(1000); ecranOled.clearDisplay();

  nfc.begin();
  if (!nfc.getFirmwareVersion()) while (1);
  nfc.SAMConfig();
  nfc.setPassiveActivationRetries(0xFF);

  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(ssid, password);
  
  if (esp_now_init() != ESP_OK) return;
  esp_now_register_recv_cb(receptionDonneesEspNow);

  initialiserServeurWeb();
}

void loop() {
  if (millis() - derniereMaJAffichage > 100) {
    mettreAJourAffichage();
    derniereMaJAffichage = millis();
  }

  // Lecture RFID seulement si on n'est pas occupé
  if (etatActuel == ETAT_ATTENTE_BADGE || etatActuel == ETAT_PRET_A_PARTIR || etatActuel == ETAT_FINI) {
    uint8_t success; uint8_t uidRaw[7]; uint8_t uidLength;
    success = nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, uidRaw, &uidLength, 50);

    if (success) {
      String uidStr = "";
      for (uint8_t i = 0; i < uidLength; i++) {
        if (uidRaw[i] < 0x10) uidStr += "0";
        uidStr += String(uidRaw[i], HEX);
        if (i < uidLength - 1) uidStr += " ";
      }
      uidStr.toUpperCase();
      
      if (uidStr != uidActuel) {
        String name = obtenirNomJoueur(uidStr);
        if (name != "") {
          nomJoueurActuel = name; uidActuel = uidStr; etatActuel = ETAT_PRET_A_PARTIR;
          digitalWrite(PIN_LED_VERTE, HIGH); delay(200); digitalWrite(PIN_LED_VERTE, LOW);
        } else {
          uidEnAttente = uidStr; etatActuel = ETAT_INSCRIPTION;
        }
      }
    }
  }
  
  if (etatActuel == ETAT_FINI && millis() - debutChrono > tempsFinal + 10000) {
    etatActuel = ETAT_ATTENTE_BADGE;
  }
}